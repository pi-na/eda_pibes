public class NumeroRepetido {

    private static boolean hasAnswer(int[] array, int from, int to) {
        int total = 0;
        for (int i : array) {
            if (i >= from && i <= to) {
                total++;
            }
        }
        return total > to - from + 1;
    }

    public static int findRepeatedNumber(int N, int[] array) {
        int from = 1;
        int to = N;
        while (to != from) {
            int middle = from + (to - from) / 2;
            boolean firstHalfHasAnswer = hasAnswer(array, from, middle);
            if (firstHalfHasAnswer) {
                to = middle;
            } else {
                from = middle + 1;
            }
        }
        return to;
    }
}
