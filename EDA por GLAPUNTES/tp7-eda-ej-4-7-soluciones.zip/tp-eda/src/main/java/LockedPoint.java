public class LockedPoint {

    public static boolean isPointLocked(boolean[][] matrix, int row, int col) {
        if (matrix[row][col]) return true;

        int total = 0;
        boolean last = false;
        int startIndex = -1;
        boolean startDirectionUp = false;
        for (int i = 0; i <= col; i++) {
            if (matrix[row][i] && !last) {
                total++;
                startIndex = i;
                startDirectionUp = row != 0 && matrix[row-1][i];
            } else if (!matrix[row][i] && last) {
                boolean endDirectionUp = row != 0 && matrix[row-1][i-1];
                if (startDirectionUp == endDirectionUp && (i - startIndex) > 1) {
                    total--;
                }
            }
            last = matrix[row][i];
        }
        return total % 2 == 1;
    }
}
