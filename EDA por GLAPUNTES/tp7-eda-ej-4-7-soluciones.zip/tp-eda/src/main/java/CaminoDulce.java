public class CaminoDulce {

    static int[][] candiesInCell;
    static Integer[][] candiesTotal;
    static int N;

    public static int maxCandies(int[][] candies) {
        candiesInCell = candies;
        N = candies.length;
        candiesTotal = new Integer[N][N];
        int max = 0;
        for (int i = 0; i < N; i++) {
            int candieCount = recCandies(i, 0);
            max = Math.max(candieCount, max);
        }
        return max;
    }

    public static int max(int i, int j, int k) {
        return Math.max(i, Math.max(j, k));
    }

    private static int recCandies(int row, int column) {
        if (row < 0 || column < 0 || row >= N || column >= N) {
            return 0;
        }
        if (candiesTotal[row][column] == null) {
            candiesTotal[row][column] = candiesInCell[row][column] +
                max(
                    recCandies(row - 1, column + 1),
                    recCandies(row, column + 1),
                    recCandies(row + 1, column + 1)
                );
        }
        return candiesTotal[row][column];
    }
}
