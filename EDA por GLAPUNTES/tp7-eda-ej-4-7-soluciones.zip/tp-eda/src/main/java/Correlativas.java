import java.util.ArrayList;
import java.util.List;

public class Correlativas {

    public static boolean canFinishDegree(int totalCourses, int[][] inputCorrelativas) {
        List<Integer>[] correlativas = new List[totalCourses];
        int[] inDegree = new int[totalCourses];
        for (int i = 0; i < totalCourses; i++) {
            correlativas[i] = new ArrayList<>();
        }
        for (int[] correlativa: inputCorrelativas) {
            correlativas[correlativa[0]].add(correlativa[1]);
            inDegree[correlativa[1]]++;
        }
        boolean[] finished = new boolean[totalCourses];
        int finishedCount = 0;
        while (finishedCount < totalCourses) {
            boolean finishedOne = false;
            for (int i = 0; i < totalCourses; i++) {
                if (inDegree[i] == 0 && !finished[i]) {
                    finished[i] = true;
                    finishedCount++;
                    finishedOne = true;
                    for (Integer correlativa: correlativas[i]) {
                        inDegree[correlativa]--;
                    }
                }
            }
            if (!finishedOne) {
                return false;
            }
        }
        return true;
    }
}
