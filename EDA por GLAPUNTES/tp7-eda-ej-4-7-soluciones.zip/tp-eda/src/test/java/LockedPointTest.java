import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LockedPointTest {

    @Test
    void isPointLocked() {
        boolean[][] matrix = new boolean[][] {
                new boolean[] { false, false, true, true, true, true, true, true, false, false },
                new boolean[] { false, false, true, false, false, false, false, true, false, false },
                new boolean[] { false, false, true, false, false, true, true, true, false, false },
                new boolean[] { false, false, true, false, false, true, false, false, false, false },
                new boolean[] { false, false, true, true, false, true, true, true, true, true },
                new boolean[] { false, false, false, true, false, false, false, false, false, true },
                new boolean[] { false, false, true, true, false, false, false, false, false, true },
                new boolean[] { false, false, true, false, false, false, false, false, false, true },
                new boolean[] { false, false, true, true, true, true, true, true, true, true },
                new boolean[] { false, false, false, false, false, false, false, false, false, false },
        };
        boolean[][] expected = new boolean[][] {
                new boolean[] { false, false, true, true, true, true, true, true, false, false },
                new boolean[] { false, false, true, true, true, true, true, true, false, false },
                new boolean[] { false, false, true, true, true, true, true, true, false, false },
                new boolean[] { false, false, true, true, true, true, false, false, false, false },
                new boolean[] { false, false, true, true, true, true, true, true, true, true },
                new boolean[] { false, false, false, true, true, true, true, true, true, true },
                new boolean[] { false, false, true, true,  true, true, true, true, true, true },
                new boolean[] { false, false, true,  true, true, true, true, true, true, true },
                new boolean[] { false, false, true, true, true, true, true, true, true, true },
                new boolean[] { false, false, false, false, false, false, false, false, false, false },
        };
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                assertEquals(expected[i][j], LockedPoint.isPointLocked(matrix, i, j));
            }
        }
    }

}