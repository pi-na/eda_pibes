import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class NumeroRepetidoTest {

    @Test
    void findRepeatedNumber() {
        int[] array = new int[]{ 2, 5, 3, 4, 3, 2 };
        int ans = NumeroRepetido.findRepeatedNumber(5, array);
        assertTrue(ans == 2 || ans == 3);
    }

    @Test
    void findRepeatedNumber2() {
        int[] array = new int[]{ 9, 7, 2, 5, 8, 5, 4, 3, 6, 1, 10 };
        int ans = NumeroRepetido.findRepeatedNumber(10, array);
        assertEquals(5, ans);
    }
}